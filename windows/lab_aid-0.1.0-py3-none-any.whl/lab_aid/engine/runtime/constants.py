"""Lab-Aid エンジンの実行制御に関する定数。"""

MAX_NEST_DEPTH = 10
MAX_FOR_ITERS = 1_000_000
